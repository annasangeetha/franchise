export const baseUrl = "https://services-platform-backend.onrender.com";
// export const baseUrl = "http://localhost:5000";